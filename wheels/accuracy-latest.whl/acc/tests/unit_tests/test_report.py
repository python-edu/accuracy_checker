import pytest
from jinja2 import DictLoader, Environment
from pandas import DataFrame
from tempfile import NamedTemporaryFile

# local import
from acc.src.report import AccuracyReport


@pytest.fixture
def mock_template():
    """Fixture providing an in-memory HTML template."""

    return """
    <!DOCTYPE html>
    <html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>{{ description_data.title }}</title>
        <style>
            {{ css_content | safe }}
        </style>
    </head>
    <body>
        <h1>{{ description_data.title }}</h1>
        <p><strong>Data generowania:</strong> {{ description_data.date }}</p>
        <p><strong>Nazwa skryptu:</strong> {{ description_data.script_name }}</p>
        <p><strong>Opis danych:</strong> {{ description_data.description }}</p>
        
        <hr>
    
        <h2>Tabele:</h2>
        {% for title, table_html in table_data.items() %}
            <h3>{{ loop.index }}. {{ title }}</h3>
            <div class="table-container">
                {{ table_html | safe }}
            </div>
        {% endfor %}
    </body>
    </html>
    """


@pytest.fixture
def sample_data():
    """Fixture providing sample data for the report."""
    return {
        "Summary": DataFrame({"A": [1, 2, 3], "B": [4, 5, 6]}),
        "Details": DataFrame({"X": [7, 8, 9], "Y": [10, 11, 12]}),
    }


@pytest.fixture
def temporary_css_file():
    """Fixture to create a temporary CSS file."""
    with NamedTemporaryFile(mode="w", suffix=".css", delete=False) as temp_file:
        temp_file.write("""
        body {
            font-family: Arial, sans-serif;
        }
        h1 {
            color: blue;
        }
        .table-container {
            margin: 10px 0;
        }
        """)
        temp_file_path = temp_file.name
    yield temp_file_path


def test_accuracy_report(mock_template, sample_data, temporary_css_file):
    """
    Test the AccuracyReport class by generating a report and reading CSS from a temporary file.
    """
    # Prepare in-memory template using DictLoader
    template_loader = DictLoader({"template.html": mock_template})
    
    # Create an instance of AccuracyReport
    report = AccuracyReport(
        title="Test Report",
        description="A test description",
        script_name="test_script.py",
        template_file="template.html",
        css_file=temporary_css_file,  # Path to temporary CSS file
    )

    # Override Jinja2 environment to use in-memory template
    report.env = Environment(loader=template_loader)
    report.template = report.env.get_template("template.html")

    # Generate the report
    html_output = report(sample_data)
    
    # Assertions
    assert "Test Report" in html_output, "The title should appear in the output."
    assert "A test description" in html_output, "The description should appear in the output."
    assert "<h3>1. Summary</h3>" in html_output, "The table title 'Summary' should appear."
    assert "<h3>2. Details</h3>" in html_output, "The table title 'Details' should appear."
    assert "font-family: Arial" in html_output, "CSS content should be included in the output."
    assert "color: blue" in html_output, "CSS content should style elements in the report."

