import pytest
import pandas as pd
import numpy as np
from acc.src.cross_matrix import CrossMatrixRecognizer 
import data_generator as gen


@pytest.fixture
def cross_raw():
    fp = gen.mock_cross_raw()
    df = pd.read_csv(fp, header=None)
    ar = df.to_numpy()
    return ar, df


@pytest.fixture
def cross():
    fp = gen.mock_cross()
    df = pd.read_csv(fp, index_col=0)
    return df


@pytest.fixture
def cross_full():
    fp = gen.mock_cross_full()
    df = pd.read_csv(fp, index_col=0)
    return df


#  --- tests ----------


def test_is_cross_raw(cross_raw):
    recognizer = CrossMatrixRecognizer
    ar, df = cross_raw

    assert True == recognizer.is_raw(ar), f"\n\tref: True\n\tres: {recognizer.is_raw({ar})}"

    assert True == recognizer.is_raw(df), f"\n\tref: True\n\tres: {recognizer.is_raw({df})}"
    assert False == recognizer.is_cross(df), f"\n\tref: False\n\tres: {recognizer.is_cross({df})}"
    assert False == recognizer.is_full(df), f"\n\tref: False\n\tres: {recognizer.is_full({df})}"


def test_is_cross(cross):
    recognizer = CrossMatrixRecognizer
    df = cross

    assert False == recognizer.is_raw(df), f"\n\tref: False\n\tres: {recognizer.is_raw({df})}"
    assert True == recognizer.is_cross(df), f"\n\tref: True\n\tres: {recognizer.is_cross({df})}"
    assert False == recognizer.is_full(df), f"\n\tref: False\n\tres: {recognizer.is_full({df})}"


def test_is_full(cross_full):
    recognizer = CrossMatrixRecognizer
    df = cross_full

    assert False == recognizer.is_raw(df), f"\n\tref: False\n\tres: {recognizer.is_raw({df})}"
    assert False == recognizer.is_cross(df), f"\n\tref: True\n\tres: {recognizer.is_cross({df})}"
    assert True == recognizer.is_full(df), f"\n\tref: False\n\tres: {recognizer.is_full({df})}"
