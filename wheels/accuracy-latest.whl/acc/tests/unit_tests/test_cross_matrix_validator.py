import pytest
import pandas as pd
import numpy as np
from acc.src.cross_matrix import CrossMatrixValidator


@pytest.fixture
def setup_raw():
    """
    Dane testowe dla macierzy typu 'raw' (bez etykiet, bez sum). Macierz
    `raw` zawsze ma być kwadratowa!!
    """
    data = [
        [1, 0, 1],
        [2, 3, 2],
        [2, 1, 0]
    ]
    return data


def _generate_cross_or_full(raw_data, add_sums=False):
    """
    Pomocnicza funkcja do generowania macierzy typu 'cross' lub 'full'
    na podstawie danych 'raw'.
    
    Args:
        raw_data: Dane surowe (macierz typu 'raw').
        add_sums: Jeśli True, dodaj sumy do macierzy (dla typu 'full').

    Returns:
        pd.DataFrame: Macierz typu 'cross' lub 'full'.
    """
    # Konwertuj dane 'raw' na DataFrame
    labels = ["cl_1", "cl_2", "cl_3"]
    data = pd.DataFrame(raw_data, columns=labels, index=labels)
    
    if add_sums:
        # Dodaj sumy w przypadku macierzy 'full'
        sums = data.sum(axis=1)
        data["sums"] = sums
        data.loc["sums"] = data.sum(axis=0)
    
    return data


@pytest.fixture
def setup_cross(setup_raw):
    """
    Dane testowe dla macierzy typu 'cross' (z etykietami, bez sum).
    """
    return _generate_cross_or_full(setup_raw, add_sums=False)


@pytest.fixture
def setup_full(setup_raw):
    """
    Dane testowe dla macierzy typu 'full' (z etykietami i sumami).
    """
    return _generate_cross_or_full(setup_raw, add_sums=True)


# --- Testy dla typu 'raw' ---

def test_raw_matrix_processing(setup_raw):
    """
    Testuje przetwarzanie macierzy 'raw'.
    """
    validator = CrossMatrixValidator(setup_raw)

    # Oczekiwane wyniki
    expected_cross_raw = pd.DataFrame(
        [
            [1, 0, 1],
            [2, 3, 2],
            [2, 1, 0]
        ],
        index=[0, 1, 2],
        columns=[0, 1, 2]
    )

    expected_cross_raw.columns.name = 'predicted'
    expected_cross_raw.index.name = 'true'

    expected_cross = pd.DataFrame(
        [
            [1, 0, 1],
            [2, 3, 2],
            [2, 1, 0]
        ],
        index=["cl_1", "cl_2", "cl_3"],
        columns=["cl_1", "cl_2", "cl_3"]
    )
    expected_cross.columns.name = 'predicted'
    expected_cross.index.name = 'true'

    expected_cross_full = pd.DataFrame(
        [
            [1, 0, 1, 2],
            [2, 3, 2, 7],
            [2, 1, 0, 3],
            [5, 4, 3, 12],
        ],
        index=["cl_1", "cl_2", "cl_3", "sums"],
        columns=["cl_1", "cl_2", "cl_3", "sums"]
    )
    expected_cross_full.columns.name = 'predicted'
    expected_cross_full.index.name = 'true'

    # Testy
    pd.testing.assert_frame_equal(validator.cross_raw, expected_cross_raw)
    pd.testing.assert_frame_equal(validator.cross, expected_cross)
    pd.testing.assert_frame_equal(validator.cross_full, expected_cross_full)

# --- Testy dla typu 'cross' ---
# --- niepełna cross!!!

@pytest.fixture
def setup_cross_asymetric():
    """
        predicted  cl_1  cl_2  cl_4
        true                       
        cl_1          4     3     0
        cl_2          3     3     2
        cl_3          1     1     1
        cl_4          1     1     0
    """
    np.random.seed(10)
    pr = np.random.choice([1,2,4], size=20)
    np.random.seed(10)
    tr = np.random.randint(1, 5, size=20)
    cross = pd.crosstab(tr, pr)
    cross.columns = [f'cl_{i}' for i in cross.columns]
    cross.index = [f'cl_{i}' for i in cross.index]
    cross.columns.name = 'predicted'
    cross.index.name = 'true'
    return cross


def _generate_raw_or_full_asymetric(setup_cross_asymetric, add_sums=False):
    """
           0  1  2  3
        0  4  3  0  0
        1  3  3  0  2
        2  1  1  0  1
        3  1  1  0  0

        and

        predicted  cl_1  cl_2  cl_4  sums
        true                             
        cl_1          4     3     0     7
        cl_2          3     3     2     8
        cl_3          1     1     1     3
        cl_4          1     1     0     2
        sums          9     8     3    20
    """
    data = setup_cross_asymetric.copy()
    if add_sums:
        # Dodaj sumy w przypadku macierzy 'full'
        sums = data.sum(axis=1)
        data["sums"] = sums
        data.loc["sums"] = data.sum(axis=0)
    else:
        data = data.reindex(columns=data.index, fill_value=0)
        data.index = range(data.shape[0])
        data.columns = range(data.shape[1])
    
    return data


@pytest.fixture
def setup_raw_asimetric(setup_cross_asymetric):
    """
    Dane testowe dla macierzy typu 'cross' (z etykietami, bez sum).
    """
    return _generate_raw_or_full_asymetric(setup_cross_asymetric, add_sums=False)


@pytest.fixture
def setup_full_asimetric(setup_cross_asymetric):
    """
    Dane testowe dla macierzy typu 'full' (z etykietami i sumami).

        predicted  cl_1  cl_2  cl_4  sums
        true                             
        cl_1          4     3     0     7
        cl_2          3     3     2     8
        cl_3          1     1     1     3
        cl_4          1     1     0     2
        sums          9     8     3    20
    """
    return _generate_raw_or_full_asymetric(setup_cross_asymetric, add_sums=True)


def test_cross_matrix_processing_asymetric_from_cross(setup_cross_asymetric):
    """
        Input: asymmetric cross matrix
    """
    raw = [
            [4, 3, 0, 0],
            [3, 3, 0, 2],
            [1, 1, 0, 1],
            [1, 1, 0, 0]
          ]

    raw_as = [
            [4, 3, 0],
            [3, 3, 2],
            [1, 1, 1],
            [1, 1, 0]
            ]
     
    validator = CrossMatrixValidator(setup_cross_asymetric)
    # Oczekiwane wyniki
    ref_cross_raw = pd.DataFrame(raw, dtype='int')
    ref_cross_raw.index = range(4)
    ref_cross_raw.columns=range(4)
    ref_cross_raw.columns.name = 'predicted'
    ref_cross_raw.index.name = 'true'

    names = [f'cl_{i}' for i in range(1, 5)]
    cols = [f'cl_{i}' for i in (1, 2, 4)]
    ref_cross_full_as = pd.DataFrame(raw_as, dtype='int')
    ref_cross_full_as.index = names 
    ref_cross_full_as.columns = cols
    ref_cross_full_as.loc[:, 'sums'] = ref_cross_full_as.sum(axis=1)
    ref_cross_full_as.loc['sums', :] = ref_cross_full_as.sum(axis=0)
    ref_cross_full_as.columns.name = 'predicted'
    ref_cross_full_as.index.name = 'true'
    ref_cross_full_as = ref_cross_full_as.astype('int')


    ref_cross_full = pd.DataFrame(raw, dtype='int')
    ref_cross_full.index = names 
    ref_cross_full.columns = names
    ref_cross_full.loc[:, 'sums'] = ref_cross_full.sum(axis=1)
    ref_cross_full.loc['sums', :] = ref_cross_full.sum(axis=0)
    ref_cross_full.columns.name = 'predicted'
    ref_cross_full.index.name = 'true'
    ref_cross_full = ref_cross_full.astype('int')
    # Testy
    # assert_pandas(validator.cross_raw, ref_cross_raw)
    # assert_pandas(validator.cross, setup_data_cross)
    # assert_pandas(validator.cross_full, ref_cross_full)
    pd.testing.assert_frame_equal(validator.cross_raw, ref_cross_raw)
    pd.testing.assert_frame_equal(validator.cross_as, setup_cross_asymetric)
    # breakpoint()
    pd.testing.assert_frame_equal(validator.cross_full_as, ref_cross_full_as)
    pd.testing.assert_frame_equal(validator.cross_full, ref_cross_full)

# --- Testy dla typu 'full' ---

def test_cross_matrix_processing_asymetric_from_cross_full(
        setup_full_asimetric,
        setup_cross_asymetric
        ):
    """
        Input: asymmetric cross matrix
    """
    raw = [
            [4, 3, 0, 0],
            [3, 3, 0, 2],
            [1, 1, 0, 1],
            [1, 1, 0, 0]
          ]

    raw_as = [
            [4, 3, 0],
            [3, 3, 2],
            [1, 1, 1],
            [1, 1, 0]
            ]
     
    validator = CrossMatrixValidator(setup_full_asimetric)
    # Oczekiwane wyniki
    ref_cross_raw = pd.DataFrame(raw, dtype='int')
    ref_cross_raw.index = range(4)
    ref_cross_raw.columns=range(4)
    ref_cross_raw.columns.name = 'predicted'
    ref_cross_raw.index.name = 'true'

    names = [f'cl_{i}' for i in range(1, 5)]
    cols = [f'cl_{i}' for i in (1, 2, 4)]
    ref_cross_full_as = pd.DataFrame(raw_as, dtype='int')
    ref_cross_full_as.index = names 
    ref_cross_full_as.columns = cols
    ref_cross_full_as.loc[:, 'sums'] = ref_cross_full_as.sum(axis=1)
    ref_cross_full_as.loc['sums', :] = ref_cross_full_as.sum(axis=0)
    ref_cross_full_as.columns.name = 'predicted'
    ref_cross_full_as.index.name = 'true'
    ref_cross_full_as = ref_cross_full_as.astype('int')


    ref_cross_full = pd.DataFrame(raw, dtype='int')
    ref_cross_full.index = names 
    ref_cross_full.columns = names
    ref_cross_full.loc[:, 'sums'] = ref_cross_full.sum(axis=1)
    ref_cross_full.loc['sums', :] = ref_cross_full.sum(axis=0)
    ref_cross_full.columns.name = 'predicted'
    ref_cross_full.index.name = 'true'
    ref_cross_full = ref_cross_full.astype('int')
    # Testy
    # assert_pandas(validator.cross_raw, ref_cross_raw)
    # assert_pandas(validator.cross, setup_data_cross)
    # assert_pandas(validator.cross_full, ref_cross_full)
    pd.testing.assert_frame_equal(validator.cross_raw, ref_cross_raw)
    # breakpoint()
    pd.testing.assert_frame_equal(validator.cross_as, setup_cross_asymetric)
    # breakpoint()
    pd.testing.assert_frame_equal(validator.cross_full_as, ref_cross_full_as)
    pd.testing.assert_frame_equal(validator.cross_full, ref_cross_full)
