import io
import tempfile
import csv
import json
from pathlib import Path

import numpy as np
import pandas as pd

# local import
from acc.src import binary_acc
from acc.src import metrics


def setup_data(ncols):
    rng = np.random.default_rng(42)
    predicted = rng.choice([1, 2, 4], size=60)
    true = rng.choice([1, 2, 3, 4], size=60)
    labels = [f'cl_{i}' for i in true]

    if ncols == 2:
        df = pd.DataFrame({'true': true, 'predicted': predicted})
    elif ncols == 3:
        df = pd.DataFrame({'true': true, 'predicted': predicted, 'labels': labels})

    df = df.sort_values('true')
    return df


def mock_data2cols():
    fp = io.StringIO()
    df = setup_data(ncols=2)
    df.to_csv(fp, index=False)
    fp.seek(0)
    return fp


def mock_data3cols():
    fp = io.StringIO()
    df = setup_data(ncols=3)
    df.to_csv(fp, index=False)
    fp.seek(0)
    return fp


def mock_cross_raw(*args, **kwargs):
    """
    cross_raw = pd.read_csv(mock_cross_raw(), header=None)
           0  1  2  3
        0  4  4  0  6
        1  2  7  0  7
        2  2  4  0  7
        3  7  6  0  4
    """
    df = setup_data(2)
    raw = pd.crosstab(df.iloc[:, 0], df.iloc[:,1])
    raw = raw.astype('int')
    raw.columns = [int(x) for x in raw.columns]
    raw.index = [int(x) for x in raw.index]
    raw = raw.reindex(columns=raw.index, fill_value=0)

    fp = io.StringIO()
    raw.to_csv(fp, index=False, header=False)
    fp.seek(0)
    return fp


def mock_cross(*args, **kwargs):
    """
    cross = pd.read_csv(mock_cross(), index_col=0)
              cl_1  cl_2  cl_4
        cl_1     4     4     6
        cl_2     2     7     7
        cl_3     2     4     7
        cl_4     7     6     4
    """
    df = setup_data(3)
    map_labels = dict(zip(df.iloc[:, 0], df.iloc[:, 2]))
    cross = pd.crosstab(df.true, df.predicted)
    cross = cross.astype('int')

    col_names = [map_labels[key] for key in cross.columns]
    raw_names = [map_labels[key] for key in cross.index]
    cross.index = raw_names[:]
    cross.columns = col_names[:]
    cross.index.name = ''
    cross.columns.name = ''

    fp = io.StringIO()
    cross.to_csv(fp)
    fp.seek(0)
    return fp


def mock_cross_full(*args, **kwargs):
    """
        pd.read_csv(mock_cross_full(), index_col=0)

              cl_1  cl_2  cl_4  sums
        cl_1     4     4     6    14
        cl_2     2     7     7    16
        cl_3     2     4     7    13
        cl_4     7     6     4    17
        sums    15    21    24    60

        pd.read_csv(mock_cross_full(ref=1), index_col=0)

              cl_1  cl_2  cl_3  cl_4  sums
        cl_1     4     4     0     6    14
        cl_2     2     7     0     7    16
        cl_3     2     4     0     7    13
        cl_4     7     6     0     4    17
        sums    15    21     0    24    60
    """
    df = setup_data(3)
    map_labels = dict(zip(df.iloc[:, 0], df.iloc[:, 2]))
    full = pd.crosstab(df.iloc[:,0], df.iloc[:, 1])
    full = full.astype('int')

    if kwargs.get('ref'):
        full = full.reindex(columns=full.index, fill_value=0)

    col_names = [map_labels[key] for key in full.columns]
    raw_names = [map_labels[key] for key in full.index]
    full.index = raw_names[:]
    full.columns = col_names[:]
    # full.index.name = ''
    # full.columns.name = ''
    
    full.loc['sums'] = full.sum(axis=0)
    full['sums'] = full.sum(axis=1)

    fp = io.StringIO()
    full.to_csv(fp)
    fp.seek(0)
    return fp


def mock_binary_cross(*args, **kwargs):
    """
            cl_1  cl_2  cl_3  cl_4
        TP     4     7     0     4
        TN    35    30    47    23
        FP    11    14     0    20
        FN    10     9    13    13
    """
    df = setup_data(3)
    map_labels = dict(zip(df.iloc[:, 0], df.iloc[:, 2]))
    cross = pd.crosstab(df.iloc[:,0], df.iloc[:, 1])
    cross = cross.astype('int')
    cross = cross.reindex(columns=cross.index, fill_value=0)

    col_names = [map_labels[key] for key in cross.columns]
    raw_names = [map_labels[key] for key in cross.index]
    cross.index = raw_names[:]
    cross.columns = col_names[:]

    bn = binary_acc.BinTable()
    binary_cross = bn(cross)

    fp = io.StringIO()
    binary_cross.to_csv(fp)
    fp.seek(0)
    return fp


def mock_binary_cross_other_labels():
    binary_cross = pd.read_csv(mock_binary_cross(), index_col=0)
    binary_cross.columns = ['aaa', 'bbb', 'ccc', 'ddd']

    fp = io.StringIO()
    binary_cross.to_csv(fp)
    fp.seek(0)
    return fp


def mock_map_labels(*args, **kwargs):
    """
    {'1': 'aaa', '2': 'bbb', '3': 'ccc', '4': 'ddd', '5': 'eee', '6': 'fff'}
    """
    labels = [3*x for x in 'abcdef']
    keys = range(1, len(labels) + 1)
    map_labels = dict(zip(keys, labels))
    fp = io.StringIO()
    json.dump(map_labels, fp, indent=2)
    fp.seek(0)
    return fp


def ref_clasic_acc(full_status=1, **kwargs):
    if full_status == 1:
        full = pd.read_csv(mock_cross_full(ref=1), index_col=0)
        cross = full.iloc[:-1, :-1]
        acc = metrics.AccClasic(cross, 4)
    elif full_status == 0:
        binary_cross = pd.read_csv(mock_binary_cross(), index_col=0)
        acc = metrics.AccClasicBin(binary_cross, 4)

    df = acc.tabela

    if kwargs.get('map_labels'):
        map_labels = kwargs.get('map_labels')
        map_labels = {int(key): val for key, val in map_labels.items()}
        # breakpoint()
        rows = [map_labels[key] for key in range(1, df.shape[0] + 1)]
        df.index = rows

    return df


def create_reference(full_status=1, **kwargs):  #new_binary=None):
    ref_cross_full = pd.DataFrame([])

    if full_status == 1:
        ref_cross_full = pd.read_csv(mock_cross_full(ref=1), index_col=0)
        if kwargs.get('map_labels'):
            i = ref_cross_full.shape[0] - 1
            names = list(kwargs['map_labels'].values())[:i]
            names.append('sums')
            ref_cross_full.columns = names
            ref_cross_full.index = names

    ref_binary_cross = pd.read_csv(mock_binary_cross(), index_col=0)
    ref_acc_classic = ref_clasic_acc(full_status=full_status, **kwargs)

    # if new_binary is not None:
    if kwargs.get('new_binary'):
        ref_binary_cross = pd.read_csv(mock_binary_cross_other_labels(), index_col=0)
    return ref_binary_cross, ref_acc_classic, ref_cross_full
