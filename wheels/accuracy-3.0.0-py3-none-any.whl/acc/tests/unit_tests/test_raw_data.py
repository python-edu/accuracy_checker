import pytest
import pandas as pd
import numpy as np
from acc.src.cross_matrix import RawData


@pytest.fixture
def input_data():
    """
    Przygotowuje dane testowe.
    """
    map_labels = {
        1: "cl_1",
        2: "cl_2",
        3: "cl_3"
    }
    true_values = [3, 2, 3, 2, 2, 1, 2, 2, 3, 1, 2, 2, 1, 5]
    predicted   = [2, 1, 1, 3, 2, 1, 1, 3, 1, 3, 2, 2, 4, 2]

    # {1: 'aaa', 2: 'bbb', ... }
    tmp_map = {i: f"{3*x}" for i, x in enumerate('abcdef', 1)}
    labels = [tmp_map[key] for key in true_values]
    return map_labels, true_values, predicted, labels

@pytest.fixture
def reference_data():
    map_labels = {
        1: "cl_1",
        2: "cl_2",
        3: "cl_3",
        5: "cl_5"
    }

    map_labels1 = {
        1: "aaa",
        2: "bbb",
        3: "ccc",
        5: "eee"
    }
    true_values = [3, 2, 3, 2, 2, 1, 2, 2, 3, 1, 2, 2, 5]
    predicted = [2, 1, 1, 3, 2, 1, 1, 3, 1, 3, 2, 2, 2]
    return map_labels, true_values, predicted, map_labels1


def test_rw_list(input_data, reference_data):
    """Input data is list: [true, predicted] and [true, predicted, labels]
    """
    map_labels, true_values, predicted, labels = input_data
    map_ref, true_ref, predicted_ref, map_ref1 = reference_data

    rw1 = RawData([true_values, predicted])
    rw2 = RawData([true_values, predicted, labels])

    assert true_ref == rw1.true_values, f"\n\tref: {true_ref}\n\tres: {rw1.true_ref}"
    assert predicted_ref == rw1.predicted, f"\n\tref: {predicted_ref}\n\tres: {rw1.predicted}"
    assert map_ref == rw1.map_labels, f"\n\tref: {map_ref}\n\tres: {rw1.map_labels}"

    assert true_ref == rw2.true_values, f"\n\tref: {true_ref}\n\tres: {rw2.true_ref}"
    assert predicted_ref == rw2.predicted, f"\n\tref: {predicted_ref}\n\tres: {rw2.predicted}"
    assert map_ref1 == rw2.map_labels, f"\n\tref: {map_ref1}\n\tres: {rw2.map_labels}"


def test_rw_array(input_data, reference_data):
    """Input data is list: [true, predicted] and [true, predicted, labels]
    """
    map_labels, true_values, predicted, labels = input_data
    map_ref, true_ref, predicted_ref, map_ref1 = reference_data

    rw1 = RawData(np.array([true_values, predicted]))
    rw2 = RawData(np.array([true_values, predicted, labels]))

    assert true_ref == rw1.true_values, f"\n\tref: {true_ref}\n\tres: {rw1.true_ref}"
    assert predicted_ref == rw1.predicted, f"\n\tref: {predicted_ref}\n\tres: {rw1.predicted}"
    assert map_ref == rw1.map_labels, f"\n\tref: {map_ref}\n\tres: {rw1.map_labels}"

    assert true_ref == rw2.true_values, f"\n\tref: {true_ref}\n\tres: {rw2.true_ref}"
    assert predicted_ref == rw2.predicted, f"\n\tref: {predicted_ref}\n\tres: {rw2.predicted}"
    assert map_ref1 == rw2.map_labels, f"\n\tref: {map_ref1}\n\tres: {rw2.map_labels}"


def test_rw_pandas(input_data, reference_data):
    """Input data is list: [true, predicted] and [true, predicted, labels]
    """
    map_labels, true_values, predicted, labels = input_data
    map_ref, true_ref, predicted_ref, map_ref1 = reference_data

    rw1 = RawData(pd.DataFrame({'true': true_values, 'predicted': predicted}))
    rw2 = RawData(pd.DataFrame({'true': true_values, 'predicted': predicted, 'label': labels}))

    assert true_ref == rw1.true_values, f"\n\tref: {true_ref}\n\tres: {rw1.true_ref}"
    assert predicted_ref == rw1.predicted, f"\n\tref: {predicted_ref}\n\tres: {rw1.predicted}"
    assert map_ref == rw1.map_labels, f"\n\tref: {map_ref}\n\tres: {rw1.map_labels}"

    assert true_ref == rw2.true_values, f"\n\tref: {true_ref}\n\tres: {rw2.true_ref}"
    assert predicted_ref == rw2.predicted, f"\n\tref: {predicted_ref}\n\tres: {rw2.predicted}"
    assert map_ref1 == rw2.map_labels, f"\n\tref: {map_ref1}\n\tres: {rw2.map_labels}"


def test_rw_list_with_map(input_data, reference_data):
    """Input data is list: [true, predicted] and [true, predicted, labels]
    """
    map_labels, true_values, predicted, labels = input_data
    map_ref, true_ref, predicted_ref, map_ref1 = reference_data

    rw1 = RawData([true_values, predicted], map_labels=map_ref1)
    rw2 = RawData([true_values, predicted, labels], map_labels=map_ref1)

    assert true_ref == rw1.true_values, f"\n\tref: {true_ref}\n\tres: {rw1.true_ref}"
    assert predicted_ref == rw1.predicted, f"\n\tref: {predicted_ref}\n\tres: {rw1.predicted}"
    assert map_ref1 == rw1.map_labels, f"\n\tref: {map_ref}\n\tres: {rw1.map_labels}"

    assert true_ref == rw2.true_values, f"\n\tref: {true_ref}\n\tres: {rw2.true_ref}"
    assert predicted_ref == rw2.predicted, f"\n\tref: {predicted_ref}\n\tres: {rw2.predicted}"
    assert map_ref1 == rw2.map_labels, f"\n\tref: {map_ref1}\n\tres: {rw2.map_labels}"
