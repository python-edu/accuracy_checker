# -*- coding: utf-8 -*-

import pytest
import pandas as pd
import numpy as np

from acc.src.metrics import AccClasic
from acc.src.metrics import AccClasicBin
from acc.src.metrics import AccIndex


# ---


@pytest.fixture(scope="module")
def acc_bin():
    """ConfusionMatrix instance"""
    acb = AccClasicBin()
    return acb


@pytest.fixture(scope="module")
def acc_index():
    """ConfusionMatrix instance"""
    acx = AccIndex()
    return acx
# ---


@pytest.fixture(scope="module")
def cross_matrix1():
    """ """
    # 1. Test clasy 'AccClasic'
    #   Dane testowe - cross matrix
    nazwy = [
        "water",
        "forest",
        "urban",
    ]  # nazwy kolumn i wierszy (są takie same)
    value = [[21, 5, 7], [6, 31, 2], [0, 1, 22]]  # liczby w komórkach
    cros = pd.DataFrame(value, columns=nazwy, index=nazwy)
    cros.axes[0].name = "referencje"
    cros.axes[1].name = "predicted"
    return cros


@pytest.fixture(scope="module")
def cros_ref1():
    ref = pd.DataFrame(
        {
            "OA": [0.7789474, 0.7789474, 0.7789474],
            "PA": [0.63636364, 0.79487179, 0.95652174],
            "UA": [0.77777778, 0.83783784, 0.70967742],
            "OME": [0.36363636, 0.20512821, 0.04347826],
            "CME": [0.22222222, 0.16216216, 0.29032258],
        },
        index=["water", "forest", "urban"],
    )
    return ref


# @pytest.fixture(scope="module")
# def cross_matrix2():
#     ad = './data/envi_cros.csv'
#     cros = pd.read_csv(ad, sep=";", index_col=0)
#     return cros

@pytest.fixture(scope="module")
def bin_tf1():
    binTF = [
        [21.0, 31.0, 22.0],
        [56.0, 50.0, 63.0],
        [6.0, 6.0, 9.0],
        [12.0, 8.0, 1.0],
    ]
    binTF = pd.DataFrame(
        binTF,
        index=["TP", "TN", "FP", "FN"],
        columns=["water", "forest", "urban"],
    )
    return binTF

@pytest.fixture(scope="module")
def ref2():
    # prawidłowe odpowiedzi 'indeksów' modern1
    tr = pd.DataFrame(
        [
            [
                0.810526316,
                0.777777778,
                0.636363636,
                0.903225806,
                0.823529412,
                0.363636364,
                0.096774194,
                0.222222222,
                0.176470588,
                0.538461538,
                0.569613037,
            ],
            [
                0.852631579,
                0.837837838,
                0.794871795,
                0.892857143,
                0.862068966,
                0.205128205,
                0.107142857,
                0.162162162,
                0.137931034,
                0.688888889,
                0.693791152,
            ],
            [
                0.894736842,
                0.709677419,
                0.956521739,
                0.875,
                0.984375,
                0.043478261,
                0.125,
                0.290322581,
                0.015625,
                0.6875,
                0.759683931,
            ],
        ]
    )

    tr.columns = [
        "acc",
        "ppv",
        "tpr",
        "tnr",
        "npv",
        "fnr",
        "fpr",
        "fdr",
        "foRate",
        "ts",
        "mcc",
    ]
    tr.index = ["water", "forest", "urban"]
    prec = 5
    tr = np.round(tr, prec)
    return tr

# ---


# testy ---

    # ustawienia
    np.set_printoptions(precision=9, linewidth=150)
    pd.set_option("expand_frame_repr", True)
    pd.set_option("precision", 9)

    # 1. Test clasy 'AccClasic'


def test_acc_clasic1(cross_matrix1, cros_ref1):
    prec = 5
    cross_matrix = cross_matrix1
    ack = AccClasic(cross_matrix, prec)
    res = ack.tabela
    ref = cros_ref1
    ref = np.round(ref, ack.precision)
    msg = f"cros:\n{cross_matrix}\n\nresult:\n{res}\n\nref:\n{ref}"
    assert ref.equals(res), print(msg)


def test_bintf(bin_tf1, ref2):
    # incjacja instancji klasy
    prec = 5
    tr = ref2
    acx = AccIndex(bin_tf1, precision=prec)
    # cl = AccIndex(binTF, precision=prec)

    for k, v in sorted(vars(acx).items()):
        if k in tr.columns.tolist():
            # wartości zamieniane są na 'int' inaczej wychodzi złe porównanie
            t = (tr.loc[:, k].to_numpy() * 10**acx.precision).tolist()
            t = [int(round(x, 0)) for x in t]

            w = (v.to_numpy() * 10**acx.precision).tolist()
            w = [int(round(x, 0)) for x in w]

            msg = f"cros:\n{k}\n\nresult:\n{w}\n\nref:\n{t}"
            assert np.all(t == w), print(msg)
