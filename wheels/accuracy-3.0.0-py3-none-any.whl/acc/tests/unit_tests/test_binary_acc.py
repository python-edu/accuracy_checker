import pytest
import pandas as pd
import numpy as np

from acc.src.binary_acc import BinTable

# ---


@pytest.fixture(scope="module")
def BT():
    """BinTable instance"""
    bt = BinTable()
    return bt


@pytest.fixture(scope="module")
def data():
    label1 = ("water", "forest", "urban")
    label2 = (1, 2, 3)
    values = ([21, 5, 7], [6, 31, 2], [0, 1, 22])
    return label1, label2, values


@pytest.fixture(scope="module")
def df1(data):
    """Tworzy kros matrix ze słownymi etykietami kolumn i wierszy:

                    water  forest  urban
        water      21       5      7
        forest      6      31      2
        urban       0       1     22
    """
    # nazwy kolumn i wierszy (są takie same)
    label1, label2, values = data
    cros = pd.DataFrame(values, columns=label1, index=label1)
    cros = cros.astype("int")
    return cros


@pytest.fixture(scope="module")
def df2(data):
    """Tworzy kros matrix z liczbowymi etykietami kolumn i wierszy.

            1   2   3
        1  21   5   7
        2   6  31   2
        3   0   1  22
    """
    label1, label2, values = data
    cros = pd.DataFrame(values, columns=label2, index=label2)
    cros = cros.astype("int")
    return cros


@pytest.fixture(scope="module")
def res1():
    """Bin table ze słownymi opisami kolumn (klas)"""
    label = ["water", "forest", "urban"]
    index = ("TP", "TN", "FP", "FN")
    values = [[21, 31, 22], [56, 50, 63], [6, 6, 9], [12, 8, 1]]
    wyn = pd.DataFrame(values, columns=label, index=index).astype("int")
    return wyn


@pytest.fixture(scope="module")
def res2():
    """Bin table z liczbowymi opisami kolumn (klas)"""
    label = [1, 2, 3]
    index = ("TP", "TN", "FP", "FN")
    values = [[21, 31, 22], [56, 50, 63], [6, 6, 9], [12, 8, 1]]
    wyn = pd.DataFrame(values, columns=label, index=index).astype("int")
    return wyn


# ---- testy ---------
# -------------------


def test_get_data(BT, df1, data):
    # res1 - dane, np.array
    # res2 - nazwy kolumn, lista nazw
    res1, res2 = BT._get_data(df1)
    label1, label2, values = data
    ref1 = np.array(values)
    ref2 = label1
    assert np.array_equal(res1, ref1), print(
        f"\nresult:\n{res1}\n", f"ref:\n{ref1}"
    )
    assert res2 == ref2, print(f"\nresult:\n{res2}\n", f"ref:\n{ref2}")
    



# ---


def test_Bin_Tabable1(BT, df1, res1):
    ref = res1.copy()
    res = BT(df1)
    assert np.array_equal(res, ref), print(
        f"\nresult:\n{res}\n", f"ref:\n{ref}"
    )


def test_Bin_Tabable2(BT, df2, res2):
    ref = res2.copy()
    res = BT(df2)
    assert np.array_equal(res, ref), print(
        f"\nresult:\n{res}\n", f"ref:\n{ref}"
    )


#
