import io
import json
import tempfile
import subprocess
import csv
from unittest.mock import patch
from pathlib import Path

import pytest
import numpy as np
import pandas as pd

from acc.src import binary_acc
from acc.src import metrics
import data_generator as gen


def read_tempfiles(dd, full_status=1):
    """dd: tempfile.TemporaryDirectory
    """
    # pth1 = str(Path(dd) / 'average_acc.csv')
    pth2 = str(Path(dd) / 'binary_cross.csv')
    pth3 = str(Path(dd) / 'classic_acc.csv')
    # pth4 = str(Path(dd) / 'complex_acc.csv')
    df5 = pd.DataFrame([]) 
    if full_status == 1:
        pth5 = str(Path(dd) / 'cross_full.csv')
        df5 = pd.read_csv(pth5, index_col=0)
    # pth6 = str(Path(dd) / 'simple_acc.csv')
    
    # df1 = pd.read_csv(pth1, index_col=0)
    df2 = pd.read_csv(pth2, index_col=0)
    df3 = pd.read_csv(pth3, index_col=0)
    # df4 = pd.read_csv(pth4, index_col=0)
    #df6 = pd.read_csv(pth6, index_col=0)
    return df2, df3, df5


def assert_me(results: list, references: list):
    for i, (res, ref) in enumerate(zip(results, references)):
        try:
            pd.testing.assert_frame_equal(res, ref)
        except Exception as ex:
            print(f'\n  nr i:{i}\nref:\n{res}\n\nres:\n{ref}\n')
            raise ex


# -------- testy ---------

def test_with_data2cols():
    mock2cols_data = gen.mock_data2cols().getvalue().encode('utf-8')
    with tempfile.TemporaryDirectory() as dd:
        with tempfile.NamedTemporaryFile(suffix=".csv") as tmp:
            tmp.write(mock2cols_data)
            tmp.seek(0)
            res = subprocess.run([f"accuracy {tmp.name} -s -o {dd}"],
                                 shell=True,
                                 capture_output=True,
                                 encoding="utf-8",
                                 check=True
                                 )

        # read results from csv outputs files (inside temporary directory)
        results = read_tempfiles(dd)
        references = gen.create_reference()
        assert_me(results, references)


def test_with_data3cols():
    mock3cols_data = gen.mock_data3cols().getvalue().encode('utf-8')
    with tempfile.TemporaryDirectory() as dd:
        with tempfile.NamedTemporaryFile(suffix=".csv") as tmp:
            tmp.write(mock3cols_data)
            tmp.seek(0)
            res = subprocess.run([f"accuracy {tmp.name} -s -o {dd}"],
                                 shell=True,
                                 capture_output=True,
                                 encoding="utf-8",
                                 check=True
                                 )

        # read results from csv outputs files (inside temporary directory)
        results = read_tempfiles(dd)
        references = gen.create_reference()
        assert_me(results, references)


def test_with_cross_raw():
    mock_df_data = gen.mock_cross_raw().getvalue().encode('utf-8')
    with tempfile.TemporaryDirectory() as dd:
        with tempfile.NamedTemporaryFile(suffix=".csv") as tmp:
            tmp.write(mock_df_data)
            tmp.seek(0)
            res = subprocess.run([f"accuracy {tmp.name} -s -o {dd}"],
                                 shell=True,
                                 capture_output=True,
                                 encoding="utf-8",
                                 check=True
                                 )

            # read result from csv output files

        results = read_tempfiles(dd)
        references = gen.create_reference()
        assert_me(results, references)


def test_with_cross_raw_and_json():
    mock_df_data = gen.mock_cross_raw().getvalue().encode('utf-8')
    map_labels_str = gen.mock_map_labels().getvalue().encode('utf-8')

    with tempfile.TemporaryDirectory() as dd:
        with tempfile.NamedTemporaryFile(suffix=".csv") as tmp_csv:
            tmp_csv.write(mock_df_data)
            tmp_csv.seek(0)
            
            with tempfile.NamedTemporaryFile(suffix=".json") as tmp_json:
                tmp_json.write(map_labels_str)
                tmp_json.seek(0)
                res = subprocess.run([f"accuracy {tmp_csv.name} {tmp_json.name} -s -o {dd}"],
                                     shell=True,
                                     capture_output=True,
                                     encoding="utf-8",
                                     check=True
                                     )

                # read result from csv output files

            results = read_tempfiles(dd)

            map_labels = json.load(gen.mock_map_labels())
            references = gen.create_reference(new_binary='yes',
                                              map_labels=map_labels
                                              )
            assert_me(results, references)

def test_with_cross():
    with tempfile.TemporaryDirectory() as dd:
        with tempfile.NamedTemporaryFile(suffix=".csv") as tmp:
            tmp.write(gen.mock_cross().getvalue().encode('utf-8'))
            tmp.seek(0)
            res = subprocess.run([f"accuracy {tmp.name} -s -o {dd}"],
                                 shell=True,
                                 capture_output=True,
                                 encoding="utf-8",
                                 check=True
                                 )

            # read result from csv output files

        results = read_tempfiles(dd)
        references = gen.create_reference()
        assert_me(results, references)
        

def test_with_cross_full():
    with tempfile.TemporaryDirectory() as dd:
        with tempfile.NamedTemporaryFile(suffix=".csv") as tmp:
            tmp.write(gen.mock_cross_full().getvalue().encode('utf-8'))
            tmp.seek(0)
            res = subprocess.run([f"accuracy {tmp.name} -s -o {dd}"],
                                 shell=True,
                                 capture_output=True,
                                 encoding="utf-8",
                                 check=True
                                 )

        # read results from csv outputs files (inside temporary directory)
        results = read_tempfiles(dd)
        references = gen.create_reference()
        assert_me(results, references)


def test_with_binary():
    with tempfile.TemporaryDirectory() as dd:
        with tempfile.NamedTemporaryFile(suffix=".csv") as tmp:
            tmp.write(gen.mock_binary_cross().getvalue().encode('utf-8'))
            tmp.seek(0)
            res = subprocess.run([f"accuracy {tmp.name} -s -o {dd}"],
                                 shell=True,
                                 capture_output=True,
                                 encoding="utf-8",
                                 check=True
                                 )

            # read result from csv output files

        results = read_tempfiles(dd, full_status=0)
        references = gen.create_reference(full_status=0)
        assert_me(results, references)
