import pytest
import pandas as pd
import numpy as np

from acc.src import data_recognition as rec
from acc.src import binary_acc


def setup_data(ncols):
    rng = np.random.default_rng(42)
    predicted = rng.choice([1, 2, 4], size=60)
    true = rng.choice([1, 2, 3, 4], size=60)
    labels = [f'cl_{i}' for i in true]

    if ncols == 2:
        df = pd.DataFrame({'true': true, 'predicted': predicted})
    elif ncols == 3:
        df = pd.DataFrame({'true': true, 'predicted': predicted, 'labels': labels})

    df = df.sort_values('true')
    return df

@pytest.fixture
def raw_data():
    """
    """
    df1 = setup_data(2)
    df2 = setup_data(3)
    return df1, df2

@pytest.fixture
def binary_matrix():
    df = setup_data(3)
    map_labels = dict(zip(df.iloc[:, 0], df.iloc[:, 2]))
    cross = pd.crosstab(df.iloc[:,0], df.iloc[:, 1])
    cross = cross.astype('int')
    cross = cross.reindex(columns=cross.index, fill_value=0)

    col_names = [map_labels[key] for key in cross.columns]
    raw_names = [map_labels[key] for key in cross.index]
    cross.index = raw_names[:]
    cross.columns = col_names[:]

    bn = binary_acc.BinTable()
    binary_cross = bn(cross)
    return binary_cross, binary_cross.T


@pytest.fixture
def cross_full():
    df = setup_data(3)
    map_labels = dict(zip(df.iloc[:, 0], df.iloc[:, 2]))
    full = pd.crosstab(df.iloc[:,0], df.iloc[:, 1])
    full = full.astype('int')

    col_names = [map_labels[key] for key in full.columns]
    raw_names = [map_labels[key] for key in full.index]
    full.index = raw_names[:]
    full.columns = col_names[:]
    
    full.loc['sums'] = full.sum(axis=0)
    full['sums'] = full.sum(axis=1)
    return full


@pytest.fixture
def cross():
    df = setup_data(3)
    map_labels = dict(zip(df.iloc[:, 0], df.iloc[:, 2]))
    cross = pd.crosstab(df.true, df.predicted)
    cross = cross.astype('int')

    col_names = [map_labels[key] for key in cross.columns]
    raw_names = [map_labels[key] for key in cross.index]
    cross.index = raw_names[:]
    cross.columns = col_names[:]
    cross.index.name = ''
    cross.columns.name = ''
    return cross


@pytest.fixture
def cross_raw():
    df = setup_data(2)
    raw = pd.crosstab(df.iloc[:, 0], df.iloc[:,1])
    raw = raw.astype('int')
    raw.columns = [int(x) for x in raw.columns]
    raw.index = [int(x) for x in raw.index]
    raw = raw.reindex(columns=raw.index, fill_value=0)
    return raw


# ------ Tests --------------

def test_check_if_int():
    assert True == rec.check_if_int(99)
    assert True == rec.check_if_int(99.1)
    assert False == rec.check_if_int('99.1')
    assert False == rec.check_if_int('abc')
    assert False == rec.check_if_int('99a')


def test_is_data_raw(raw_data, binary_matrix, cross_full, cross, cross_raw):
    df1, df2 = raw_data
    check, meta = rec.is_data_raw(df1)
    assert True == check

    check, meta = rec.is_data_raw(df2)
    assert True == check

    df1, df2 = binary_matrix
    check, meta = rec.is_data_raw(df1)
    assert False == check

    check, meta = rec.is_data_raw(df2)
    assert False == check

    df = cross_full
    check, meta = rec.is_data_raw(df)
    assert False == check

    df = cross
    check, meta = rec.is_data_raw(df)
    assert False == check

    df = cross_raw
    check, meta = rec.is_data_raw(df)
    assert False == check


def test_is_binary_matrix(raw_data, binary_matrix, cross_full, cross, cross_raw):
    df1, df2 = raw_data
    check, meta = rec.is_binary_matrix(df1)
    assert False == check

    check, meta = rec.is_binary_matrix(df2)
    assert False == check

    df1, df2 = binary_matrix
    check, meta = rec.is_binary_matrix(df1)
    assert True == check, f"\n\tdf1:\n{df1}\n"

    check, meta = rec.is_binary_matrix(df2)
    assert True == check, f"\n\tdf2:\n{df2}\n"

    df = cross_full
    check, meta = rec.is_binary_matrix(df)
    assert False == check

    df = cross
    check, meta = rec.is_binary_matrix(df)
    assert False == check

    df = cross_raw
    check, meta = rec.is_binary_matrix(df)
    assert False == check


def test_is_cross_raw(raw_data, binary_matrix, cross_full, cross, cross_raw):
    df1, df2 = raw_data
    check, meta = rec.is_cross_raw(df1)
    assert False == check

    check, meta = rec.is_cross_raw(df2)
    assert False == check

    df1, df2 = binary_matrix
    check, meta = rec.is_cross_raw(df1)
    assert False == check, f"\n\tdf1:\n{df1}\n"

    check, meta = rec.is_cross_raw(df2)
    assert False == check, f"\n\tdf2:\n{df2}\n"

    df = cross_full
    check, meta = rec.is_cross_raw(df)
    assert False == check

    df = cross
    check, meta = rec.is_cross_raw(df)
    assert False == check

    df = cross_raw
    check, meta = rec.is_cross_raw(df)
    assert True == check


def test_is_cross(raw_data, binary_matrix, cross_full, cross, cross_raw):
    df1, df2 = raw_data
    check, meta = rec.is_cross_matrix(df1)
    assert False == check

    check, meta = rec.is_cross_matrix(df2)
    assert False == check

    df1, df2 = binary_matrix
    check, meta = rec.is_cross_matrix(df1)
    assert False == check, f"\n\tdf1:\n{df1}\n"

    check, meta = rec.is_cross_matrix(df2)
    assert False == check, f"\n\tdf2:\n{df2}\n"

    df = cross_full
    check, meta = rec.is_cross_matrix(df)
    assert False == check

    df = cross
    check, meta = rec.is_cross_matrix(df)
    assert True == check

    df = cross_raw
    check, meta = rec.is_cross_matrix(df)
    assert False == check


def test_is_cross_full(raw_data, binary_matrix, cross_full, cross, cross_raw):
    df1, df2 = raw_data
    check, meta = rec.is_cross_full(df1)
    assert False == check

    check, meta = rec.is_cross_full(df2)
    assert False == check

    df1, df2 = binary_matrix
    check, meta = rec.is_cross_full(df1)
    assert False == check, f"\n\tdf1:\n{df1}\n"

    check, meta = rec.is_cross_full(df2)
    assert False == check, f"\n\tdf2:\n{df2}\n"

    df = cross_full
    check, meta = rec.is_cross_full(df)
    assert True == check

    df = cross
    check, meta = rec.is_cross_full(df)
    assert False == check

    df = cross_raw
    check, meta = rec.is_cross_full(df)
    assert False == check
