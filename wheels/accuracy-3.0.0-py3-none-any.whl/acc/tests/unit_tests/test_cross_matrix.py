import pytest
import pandas as pd
import numpy as np
from acc.src.cross_matrix import CrossMatrix


@pytest.fixture
def setup_data():
    """
    Przygotowuje dane testowe.
    """
    map_labels = {
        1: "cl_01",
        2: "cl_02",
        3: "cl_03"
    }
    true_values = [3, 2, 3, 2, 2, 1, 2, 2, 3, 1, 2, 2]
    predicted = [2, 1, 1, 3, 2, 1, 1, 3, 1, 3, 2, 2]
    return map_labels, true_values, predicted


@pytest.fixture
def setup_data_asymetric():
    """
    Przygotowuje dane testowe: klas true jest więcej niż predict!!!
    """
    map_labels = {
        1: "cl_01",
        2: "cl_02",
        3: "cl_03",
        4: "cl_04"
    }
    np.random.seed(10)
    true_values = np.random.randint(1, 5, size=20)
    np.random.seed(10)
    predicted = np.random.choice([1,2,4], size=20)
    return map_labels, true_values, predicted


@pytest.fixture
def reference_cross_raw(setup_data):

    raw = pd.DataFrame(
            [[1, 0, 1],
             [2, 3, 2],
             [2, 1, 0]],
        index=[0, 1, 2],
        columns=[0, 1, 2]
    )
    raw.columns.name = 'predicted'
    raw.index.name = 'true'
    return raw


@pytest.fixture
def reference_cross_raw_asimetric(setup_data):

    raw = pd.DataFrame(
            [
                [4, 3, 0, 0],
                [3, 3, 0, 2],
                [1, 1, 0, 1],
                [1, 1, 0, 0]
             ],
        index=[0, 1, 2, 3],
        columns=[0, 1, 2, 3]
    )
    raw.columns.name = 'predicted'
    raw.index.name = 'true'
    return raw


# ---------- Tests ------------------

def test_add_summaries(setup_data, reference_cross_raw):
    map_labels, true_values, predicted = setup_data
    ref_cross_raw = reference_cross_raw

    cm = CrossMatrix(true_values, predicted, map_labels)
    res = cm._add_summaries(ref_cross_raw)

    ref_cross_raw.loc['sums'] = ref_cross_raw.sum(axis=0)
    ref_cross_raw['sums'] = ref_cross_raw.sum(axis=1)

    pd.testing.assert_frame_equal(res, ref_cross_raw)


def test_cross_raw(setup_data, reference_cross_raw):
    """
    Testuje generowanie surowej macierzy (cross_raw).
    """
    map_labels, true_values, predicted = setup_data
    matrix = CrossMatrix(true_values, predicted, map_labels)
    reference = reference_cross_raw

    pd.testing.assert_frame_equal(matrix.cross_raw, reference)


def test_cross(setup_data, reference_cross_raw):
    """
    Testuje generowanie macierzy z opisami (cross).
    """
    map_labels, true_values, predicted = setup_data
    matrix = CrossMatrix(true_values, predicted, map_labels)
    reference = reference_cross_raw

    reference.columns = ["cl_01", "cl_02", "cl_03"]
    reference.index = ["cl_01", "cl_02", "cl_03"]
    reference.columns.name = 'predicted'
    reference.index.name = 'true'

    pd.testing.assert_frame_equal(matrix.cross, reference)


def test_cross_full(setup_data):
    """
    Testuje generowanie macierzy z opisami i podsumowaniami (cross_full).
    """
    map_labels, true_values, predicted = setup_data
    matrix = CrossMatrix(true_values, predicted, map_labels)

    reference = pd.DataFrame(
            [[1, 0, 1, 2],
             [2, 3, 2, 7],
             [2, 1, 0, 3],
             [5, 4, 3, 12]],
        index=["cl_01", "cl_02", "cl_03", "sums"],
        columns=["cl_01", "cl_02", "cl_03", "sums"]
    )

    reference.columns.name = 'predicted'
    reference.index.name = 'true'

    pd.testing.assert_frame_equal(matrix.cross_full, reference)


def test_cross_raw_asymetric(setup_data_asymetric,
                             reference_cross_raw_asimetric):
    """
    Testuje generowanie surowej macierzy (cross_raw).
    """
    map_labels, true_values, predicted = setup_data_asymetric
    matrix = CrossMatrix(true_values, predicted, map_labels)
    reference = reference_cross_raw_asimetric

    pd.testing.assert_frame_equal(matrix.cross_raw, reference)


def test_cross_asymetric(setup_data_asymetric, reference_cross_raw_asimetric):
    """
    Testuje generowanie macierzy z opisami (cross).
    """
    map_labels, true_values, predicted = setup_data_asymetric
    matrix = CrossMatrix(true_values, predicted, map_labels)
    reference = reference_cross_raw_asimetric

    reference.columns = ["cl_01", "cl_02", "cl_03", "cl_04"]
    reference.index = ["cl_01", "cl_02", "cl_03", "cl_04"]
    reference.columns.name = 'predicted'
    reference.index.name = 'true'

    pd.testing.assert_frame_equal(matrix.cross, reference)
