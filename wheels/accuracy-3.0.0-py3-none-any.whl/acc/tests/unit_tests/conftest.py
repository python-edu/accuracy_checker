# conftest.py

import pandas as pd
import pytest

def pytest_assertrepr_compare(op, left, right):
    """
    Niestandardowe formatowanie porównania dwóch DataFrame'ów.
    """
    if isinstance(left, pd.DataFrame) and isinstance(right, pd.DataFrame):
        try:
            # Próba porównania DataFrame'ów
            pd.testing.assert_frame_equal(left, right)
        except AssertionError as e:
            # Zwrócenie szczegółowych różnic
            return [
                "Różnice między DataFrame'ami:",
                f"Lewa strona:\n\n{left.to_string(index=True)}\n",
                f"Prawa strona:\n\n{right.to_string(index=True)}\n",
                str(e)  # Dodanie szczegółów błędu
            ]

