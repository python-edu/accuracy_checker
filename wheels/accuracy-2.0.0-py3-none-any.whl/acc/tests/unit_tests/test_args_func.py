from argparse import Namespace
from unittest.mock import patch, MagicMock
import pytest
import sys
from pathlib import Path

import json
from collections import Counter

from acc.src.args_data.args_func import check_file_path, check_dir, parse_report_data
from acc.src.args_data.args_func import detects_separator, search_reference_file, search_json_file
from acc.src.args_data.args_func import paths_decoder, args_validation


# ------------------------------
# Tests for check_file_path
# ------------------------------
def test_check_file_path_valid_file(tmp_path):
    # Create a temporary file
    valid_file = tmp_path / "valid_file.txt"
    valid_file.touch()
    # breakpoint()
    # Test with a valid file path
    result = check_file_path(str(valid_file))
    assert result == str(valid_file.resolve())


def test_check_file_path_invalid_file():
    # Test with an invalid file path
    invalid_file = "non_existent_file.txt"
    with pytest.raises(SystemExit) as excinfo:
        check_file_path(invalid_file)
    assert f"`{invalid_file}` is not a valid file path." in str(excinfo.value)


# ------------------------------
# Tests for check_dir
# ------------------------------
def test_check_dir_default_results_dir(tmp_path):
    # Input CSV path
    csv_file = tmp_path / "data.csv"
    csv_file.touch()

    # Test default results directory creation
    result = check_dir(str(csv_file), None)
    expected_dir = tmp_path / "data_results"
    assert result == str(expected_dir.resolve())


def test_check_dir_with_name(tmp_path):
    # Input CSV path
    csv_file = tmp_path / "data.csv"
    csv_file.touch()

    # Test with output directory name
    result = check_dir(str(csv_file), "custom_dir")
    expected_dir = tmp_path / "custom_dir"
    assert result == str(expected_dir.resolve())


def test_check_dir_with_absolute_path(tmp_path):
    # Input CSV path
    csv_file = tmp_path / "data.csv"
    csv_file.touch()

    # Test with absolute output directory path
    custom_dir = tmp_path / "absolute_custom_dir"
    result = check_dir(str(csv_file), str(custom_dir))
    assert result == str(custom_dir.resolve())


# ------------------------------
# Tests for parse_report_data
# ------------------------------
def test_parse_report_data_valid():
    # Test with valid data
    input_data = ["key1=value1", "key2=value2", "key3=value3"]
    result = parse_report_data(input_data)
    expected_result = {
        "key1": "value1",
        "key2": "value2",
        "key3": "value3"
    }
    assert result == expected_result


def test_parse_report_data_empty():
    # Test with empty input
    input_data = []
    result = parse_report_data(input_data)
    assert result == {}


def test_parse_report_data_invalid_format():
    # Test with invalid data format
    input_data = ["key1=value1", "key2value2"]  # Missing '=' in the second item
    with pytest.raises(ValueError):
        parse_report_data(input_data)






# ------------------------------
# Tests for detects_separator
# ------------------------------
def test_detects_separator_comma(tmp_path):
    csv_file = tmp_path / "test.csv"
    csv_content = "col1,col2,col3\n1,2,3\n4,5,6\n"
    csv_file.write_text(csv_content)

    assert detects_separator(str(csv_file)) == ","


def test_detects_separator_semicolon(tmp_path):
    csv_file = tmp_path / "test.csv"
    csv_content = "col1;col2;col3\n1;2;3\n4;5;6\n"
    csv_file.write_text(csv_content)

    assert detects_separator(str(csv_file)) == ";"


def test_detects_separator_tab(tmp_path):
    csv_file = tmp_path / "test.csv"
    csv_content = "col1\tcol2\tcol3\n1\t2\t3\n4\t5\t6\n"
    csv_file.write_text(csv_content)

    assert detects_separator(str(csv_file)) == "\t"


# ------------------------------
# Tests for search_reference_file
# ------------------------------
def test_search_reference_file_found(tmp_path):
    base_file = tmp_path / "data.csv"
    ref_file = tmp_path / "data_ref.tif"
    base_file.touch()
    ref_file.touch()

    result = search_reference_file(str(base_file))
    assert result == str(ref_file.resolve())


def test_search_reference_file_not_found(tmp_path):
    base_file = tmp_path / "data.csv"
    base_file.touch()

    result = search_reference_file(str(base_file))
    assert result is False


# ------------------------------
# Tests for search_json_file
# ------------------------------
def test_search_json_file_found(tmp_path):
    json_file = tmp_path / "class_map.json"
    json_content = {"1": "Class A", "2": "Class B"}
    json_file.write_text(json.dumps(json_content))

    result = search_json_file(str(tmp_path))
    expected_result = {1: "Class A", 2: "Class B"}
    assert result == expected_result


def test_search_json_file_not_found(tmp_path):
    result = search_json_file(str(tmp_path))
    assert result is None


def test_search_json_file_invalid_json(tmp_path):
    json_file = tmp_path / "class_map.json"
    json_content = "{invalid_json}"
    json_file.write_text(json_content)

    result = search_json_file(str(tmp_path))
    assert result is None


def test_search_json_file_invalid_keys(tmp_path):
    json_file = tmp_path / "class_map.json"
    json_content = {"key1": "Class A", "key2": "Class B"}
    json_file.write_text(json.dumps(json_content))

    result = search_json_file(str(tmp_path))
    # Invalid keys should remain strings since they can't be converted to int
    expected_result = {"key1": "Class A", "key2": "Class B"}
    assert result == expected_result






# Mock for check_file_path
def mock_check_file_path(path):
    return str(Path(path).resolve())


@pytest.fixture
def mock_args():
    return Namespace(path=[])


@patch("acc.src.args_data.args_func.check_file_path", side_effect=mock_check_file_path)
def test_single_csv(mock_check, mock_args):
    mock_args.path = ["data.csv"]
    result = paths_decoder(mock_args)
    assert result.path == str(Path("data.csv").resolve())


@patch("acc.src.args_data.args_func.check_file_path", side_effect=mock_check_file_path)
def test_single_tif(mock_check, mock_args):
    mock_args.path = ["image.tif"]
    result = paths_decoder(mock_args)
    assert result.path == str(Path("image.tif").resolve())
    assert result.path2 is None


@patch("acc.src.args_data.args_func.check_file_path", side_effect=mock_check_file_path)
def test_two_paths_tif_json(mock_check, mock_args):
    mock_args.path = ["image.tif", "config.json"]
    result = paths_decoder(mock_args)
    assert result.path == str(Path("image.tif").resolve())
    assert result.path3 == str(Path("config.json").resolve())
    assert result.path2 is None


@patch("acc.src.args_data.args_func.check_file_path", side_effect=mock_check_file_path)
def test_two_paths_tif_shp(mock_check, mock_args):
    mock_args.path = ["image.tif", "reference.shp"]
    result = paths_decoder(mock_args)
    assert result.path == str(Path("image.tif").resolve())
    assert result.path2 == str(Path("reference.shp").resolve())
    assert result.path3 is None


@patch("acc.src.args_data.args_func.check_file_path", side_effect=mock_check_file_path)
def test_three_paths(mock_check, mock_args):
    mock_args.path = ["image.tif", "reference.shp", "config.json"]
    result = paths_decoder(mock_args)
    assert result.path == str(Path("image.tif").resolve())
    assert result.path2 == str(Path("reference.shp").resolve())
    assert result.path3 == str(Path("config.json").resolve())


def test_invalid_too_many_paths(mock_args):
    mock_args.path = ["path1", "path2", "path3", "path4"]
    with pytest.raises(SystemExit):
        paths_decoder(mock_args)


def test_invalid_path_combination(mock_args):
    mock_args.path = ["image.txt", "reference.shp"]
    with pytest.raises(SystemExit):
        paths_decoder(mock_args)





@patch("acc.src.args_data.args_func.paths_decoder", side_effect=lambda x: x)
@patch("acc.src.args_data.args_func.search_reference_file", return_value="/mocked/reference.shp")
@patch("acc.src.args_data.args_func.detects_separator", return_value=",")
@patch("acc.src.args_data.args_func.parse_report_data", side_effect=lambda x: x)
def test_args_validation(
    mock_decoder, mock_search_ref, mock_sep, mock_parse, tmp_path
):
    # Use tmp_path to create a valid temporary output directory
    output_dir = tmp_path / "output"
    with patch("acc.src.args_data.args_func.check_dir", return_value=str(output_dir)):
        args = Namespace(
            save=True,
            zip=False,
            report=True,
            path="mocked.csv",
            path2=None,
            path3=None,
            report_data={"template_dir": ".", "report_file": "report.txt"},
            out_dir=None,
            sep=None,
        )
        updated_args = args_validation(args, script_name="test_script")

        # Assertions
        assert updated_args.path == "mocked.csv"
        assert updated_args.report_data["report_file"] == str(output_dir / "report.txt")
        assert updated_args.script_name == "test_script"
        assert Path(output_dir).exists()  # Ensure the directory was created


def test_args_validation_conflict():
    args = Namespace(save=True, zip=True, path="mocked.csv")
    with pytest.raises(SystemExit):
        args_validation(args)
